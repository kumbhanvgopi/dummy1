"""
run.py  —  place inside backend/ and run:  python run.py
"""
import os, sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import uvicorn

if __name__ == "__main__":
    print("=" * 55)
    print("  Suprajit — SAP Transaction Hub  (FastAPI)")
    print("=" * 55)
    print("  Login   -> http://127.0.0.1:8000/")
    print("  Docs    -> http://127.0.0.1:8000/docs")
    print("  Health  -> http://127.0.0.1:8000/api/health")
    print("=" * 55)
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=False)
