"""
sap_client.py
-------------
All SAP OData HTTP calls in one place.

Confirmed services (Adesh Parandkar, 29-04-2026):
  ZUI_AT_TOOLS / ZI_BatchStocks          — plants, storage locs, batch details
  ZUI_AT_TOOLS / I_Batch                 — batch stock qty
  ZUI_AT_TOOLS / I_MaterialDocumentHeader_2 — duplicate check
  ZAPI_MATERIAL_DOCUMENT_SRV             — post load (341) / unload (312)

Credentials: entered by user on login screen (not hardcoded).
SAP system:  http://10.1.2.57:44300  |  client: 110
"""

import requests
import urllib3
from typing import Dict, List, Optional

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

TIMEOUT = 30


def _get(url: str, username: str, password: str) -> Dict:
    """Raw GET — returns parsed JSON or raises RuntimeError."""
    try:
        resp = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=TIMEOUT,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:300]}")
        return resp.json()
    except requests.exceptions.ConnectionError:
        raise RuntimeError("Cannot connect to SAP. Check the SAP Base URL.")
    except requests.exceptions.Timeout:
        raise RuntimeError("SAP request timed out. Check network connectivity.")


def _csrf_token(base_url: str, service: str, username: str, password: str) -> str:
    """Fetch CSRF token needed before any OData POST."""
    url = f"{base_url}/{service}/"
    try:
        resp = requests.head(
            url,
            auth=(username, password),
            headers={"x-csrf-token": "Fetch", "Accept": "application/json"},
            verify=False,
            timeout=TIMEOUT,
        )
        token = resp.headers.get("x-csrf-token", "")
        if not token:
            raise RuntimeError(
                "CSRF token not returned. Check SAP user authorisations."
            )
        return token
    except requests.exceptions.ConnectionError:
        raise RuntimeError("Cannot connect to SAP for CSRF token.")


def _post(
    url: str,
    payload: Dict,
    username: str,
    password: str,
    csrf_token: str,
) -> Dict:
    """Raw POST with CSRF token — returns parsed JSON or raises RuntimeError."""
    try:
        resp = requests.post(
            url,
            json=payload,
            auth=(username, password),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "x-csrf-token": csrf_token,
            },
            verify=False,
            timeout=TIMEOUT,
        )
        if resp.status_code not in (200, 201):
            # Try to parse SAP error message
            try:
                err = resp.json()
                msg = err.get("error", {}).get("message", {}).get("value", resp.text)
            except Exception:
                msg = resp.text[:300]
            raise RuntimeError(f"SAP error {resp.status_code}: {msg}")
        return resp.json() if resp.content else {}
    except requests.exceptions.ConnectionError:
        raise RuntimeError("Cannot connect to SAP for POST.")


# ─────────────────────────────────────────────────────────────────────────────
# PLANTS
# ─────────────────────────────────────────────────────────────────────────────

def get_plants(username: str, password: str, base_url: str, client: str) -> List[Dict]:
    """
    Fetch unique plants from ZI_BatchStocks.
    Returns [{Plant, PlantName}]
    """
    url = (
        f"{base_url}/ZI_BatchStocks"
        f"?sap-client={client}&$select=Plant&$top=1000&$format=json"
    )
    try:
        data = _get(url, username, password)
        results = data.get("d", {}).get("results", [])
        seen = set()
        plants = []
        for item in results:
            p = (item.get("Plant") or item.get("Werks") or "").strip()
            if p and p not in seen:
                seen.add(p)
                plants.append({"Plant": p, "PlantName": f"Plant {p}"})
        return sorted(plants, key=lambda x: x["Plant"])
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# STORAGE LOCATIONS
# ─────────────────────────────────────────────────────────────────────────────

def get_storage_locations(
    username: str, password: str, base_url: str, client: str, plant: str
) -> List[Dict]:
    """
    Fetch unique storage locations for a plant from ZI_BatchStocks.
    Returns [{StorageLocation, StorageLocationName}]
    """
    url = (
        f"{base_url}/ZI_BatchStocks"
        f"?sap-client={client}"
        f"&$filter=Plant eq '{plant}'"
        f"&$select=StorageLocation&$top=1000&$format=json"
    )
    try:
        data = _get(url, username, password)
        results = data.get("d", {}).get("results", [])
        seen = set()
        slocs = []
        for item in results:
            s = (item.get("StorageLocation") or item.get("Lgort") or "").strip()
            if s and s not in seen:
                seen.add(s)
                slocs.append({
                    "StorageLocation": s,
                    "StorageLocationName": f"Storage {s}",
                })
        return sorted(slocs, key=lambda x: x["StorageLocation"])
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# BATCH DETAILS
# ─────────────────────────────────────────────────────────────────────────────

def get_batch_details(
    username: str,
    password: str,
    base_url: str,
    client: str,
    batch_number: str,
    plant: str,
    from_storage: str,
) -> Dict:
    """
    Fetch batch details from ZI_BatchStocks.
    Returns {success, batch, material, material_name, plant, unit, quantity, storage_location}
    """
    filter_parts = [
        f"Batch eq '{batch_number}'",
        f"Plant eq '{plant}'",
    ]
    if from_storage:
        filter_parts.append(f"StorageLocation eq '{from_storage}'")

    url = (
        f"{base_url}/ZI_BatchStocks"
        f"?sap-client={client}"
        f"&$filter={' and '.join(filter_parts)}"
        f"&$format=json"
    )

    try:
        data = _get(url, username, password)
        results = data.get("d", {}).get("results", [])

        if not results:
            return {
                "success": False,
                "message": f"Batch '{batch_number}' not found in plant {plant} / storage {from_storage}",
            }

        item = results[0]
        material = (
            item.get("Material") or item.get("Matnr") or ""
        ).strip()

        if not material:
            return {
                "success": False,
                "message": f"No material found for batch '{batch_number}'",
            }

        qty_raw = item.get("Quantity") or item.get("Labst") or item.get("MatlWrhsStkQtyInMatlBaseUnit") or 0
        try:
            qty = float(qty_raw)
        except (TypeError, ValueError):
            qty = 0.0

        return {
            "success": True,
            "batch": (item.get("Batch") or item.get("Charg") or batch_number).strip(),
            "material": material,
            "material_name": (item.get("MaterialName") or item.get("Maktx") or item.get("MaterialDescription") or "").strip(),
            "plant": (item.get("Plant") or item.get("Werks") or plant).strip(),
            "unit": (item.get("Unit") or item.get("Meins") or item.get("BaseUnit") or "EA").strip(),
            "quantity": qty,
            "storage_location": (item.get("StorageLocation") or item.get("Lgort") or from_storage).strip(),
        }
    except RuntimeError as e:
        return {"success": False, "message": str(e)}
    except Exception as e:
        return {"success": False, "message": f"Error fetching batch: {e}"}


# ─────────────────────────────────────────────────────────────────────────────
# BATCH STOCK CHECK
# ─────────────────────────────────────────────────────────────────────────────

def check_batch_stock(
    username: str,
    password: str,
    base_url: str,
    client: str,
    material: str,
    plant: str,
    storage_location: str,
    batch: str,
) -> Dict:
    """
    Check unrestricted stock for a batch.
    First tries ZUI_AT_TOOLS/I_Batch (confirmed by team),
    then falls back to ZI_BatchStocks quantity field.
    Returns {unrestricted, quality, blocked}
    """
    # Try I_Batch first — confirmed by SAP team
    try:
        url = (
            f"{base_url}/I_Batch"
            f"?sap-client={client}"
            f"&$filter=Material eq '{material}'"
            f" and Plant eq '{plant}'"
            f" and StorageLocation eq '{storage_location}'"
            f" and Batch eq '{batch}'"
            f"&$format=json"
        )
        data = _get(url, username, password)
        results = data.get("d", {}).get("results", [])
        if results:
            r = results[0]
            qty = float(
                r.get("UnrestrictedQuantity")
                or r.get("AvailableQuantity")
                or r.get("StockQuantity")
                or r.get("Quantity")
                or 0
            )
            return {"unrestricted": qty, "quality": 0.0, "blocked": 0.0}
    except Exception:
        pass

    # Fallback — get qty from ZI_BatchStocks
    try:
        details = get_batch_details(
            username, password, base_url, client, batch, plant, storage_location
        )
        if details.get("success"):
            return {
                "unrestricted": float(details.get("quantity", 0)),
                "quality": 0.0,
                "blocked": 0.0,
            }
    except Exception:
        pass

    return {"unrestricted": 0.0, "quality": 0.0, "blocked": 0.0}


# ─────────────────────────────────────────────────────────────────────────────
# DUPLICATE CHECK
# ─────────────────────────────────────────────────────────────────────────────

def check_duplicate_header(
    username: str,
    password: str,
    base_url: str,
    client: str,
    header_text: str,
    year: str,
) -> List[Dict]:
    """
    Check if a header text / reference document was already used this year.
    Uses ZUI_AT_TOOLS / I_MaterialDocumentHeader_2 (confirmed by team).
    Returns list of matching docs — empty = no duplicate.
    """
    try:
        url = (
            f"{base_url}/I_MaterialDocumentHeader_2"
            f"?sap-client={client}"
            f"&$filter=ReferenceDocumentNumber eq '{header_text}'"
            f" and FiscalYear eq '{year}'"
            f"&$select=MaterialDocument,FiscalYear,PostingDate,CreatedByUser"
            f"&$top=5&$format=json"
        )
        data = _get(url, username, password)
        results = data.get("d", {}).get("results", [])
        return [
            {
                "mblnr": r.get("MaterialDocument", ""),
                "mjahr": r.get("FiscalYear", ""),
                "posting_date": r.get("PostingDate", ""),
                "user": r.get("CreatedByUser", ""),
            }
            for r in results
        ]
    except Exception:
        return []  # non-fatal — allow posting to proceed if check fails


# ─────────────────────────────────────────────────────────────────────────────
# POST MATERIAL DOCUMENT
# ─────────────────────────────────────────────────────────────────────────────

def post_material_document(
    username: str,
    password: str,
    base_url: str,
    client: str,
    batch_items: List[Dict],
    from_storage: str,
    to_storage: str,
    movement_type: str,
    header_text: str,
) -> Dict:
    """
    Post a material document via ZAPI_MATERIAL_DOCUMENT_SRV.
    movement_type: '311' (storage-to-storage), '341' (load), '312' (unload)

    Returns {success, material_document_number, timestamp, message}
    """
    import datetime

    service = "ZAPI_MATERIAL_DOCUMENT_SRV"
    # SAP OData path for this service
    svc_base = base_url.replace("ZUI_AT_TOOLS", service)
    # Reconstruct cleanly from base
    # base_url comes in as e.g. https://10.1.2.57:44300/sap/opu/odata/sap/ZUI_AT_TOOLS
    # We need https://10.1.2.57:44300/sap/opu/odata/sap/ZAPI_MATERIAL_DOCUMENT_SRV
    parts = base_url.rstrip("/").rsplit("/", 1)
    svc_base = f"{parts[0]}/{service}"

    posting_date = datetime.date.today().isoformat()

    items = []
    for item in batch_items:
        qty = float(item.get("quantity", 0))
        if qty <= 0:
            continue
        entry = {
            "Material":            item["material"].strip(),
            "Plant":               item["plant"].strip().zfill(4),
            "GoodsMovementType":   movement_type,
            "StorageLocation":     from_storage.strip().zfill(4),
            "DestinationStorLoc":  to_storage.strip().zfill(4),
            "QuantityInEntryUnit": str(qty),
            "EntryUnit":           item.get("unit", "EA"),
        }
        if item.get("batch", "").strip():
            entry["Batch"] = item["batch"].strip()
        items.append(entry)

    if not items:
        return {"success": False, "message": "No valid line items to post"}

    payload = {
        "DocumentDate":               posting_date,
        "PostingDate":                posting_date,
        "MaterialDocumentHeaderText": header_text,
        "ReferenceDocument":          header_text,
        "to_MaterialDocumentItem":    items,
    }

    try:
        csrf = _csrf_token(svc_base.replace(f"/{service}", ""), service, username, password)
    except Exception:
        # Try fetching CSRF from the service URL directly
        try:
            resp = requests.head(
                f"{svc_base}/",
                auth=(username, password),
                headers={"x-csrf-token": "Fetch"},
                verify=False,
                timeout=TIMEOUT,
            )
            csrf = resp.headers.get("x-csrf-token", "")
            if not csrf:
                raise RuntimeError("No CSRF token returned")
        except Exception as e:
            return {"success": False, "message": f"CSRF token error: {e}"}

    post_url = f"{svc_base}/A_MaterialDocumentHeader?$format=json&sap-client={client}"

    try:
        result = _post(post_url, payload, username, password, csrf)
        d = result.get("d", result)
        mblnr = d.get("MaterialDocument", "").strip()
        mjahr = d.get("MaterialDocumentYear", "").strip()

        if not mblnr:
            return {
                "success": False,
                "message": "SAP returned no document number. Check movement type and authorisations.",
            }

        return {
            "success": True,
            "material_document_number": mblnr,
            "mjahr": mjahr,
            "message": f"Posted successfully. Document: {mblnr}/{mjahr}",
            "timestamp": datetime.datetime.now().isoformat(),
        }
    except RuntimeError as e:
        return {"success": False, "message": str(e)}
    except Exception as e:
        return {"success": False, "message": f"Posting error: {e}"}
