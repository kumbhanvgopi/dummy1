"""
main.py
-------
Suprajit SAP Transaction Hub — FastAPI backend.

Routes match their frontend (login.html, dashboard.html, load_truck.html) exactly.
Uses Jinja2 templates + session middleware — same behaviour as original Flask app.

SAP services (confirmed by team 29-04-2026):
  ZUI_AT_TOOLS / ZI_BatchStocks          — plants, storage locs, batch details
  ZUI_AT_TOOLS / I_Batch                 — batch stock qty
  ZUI_AT_TOOLS / I_MaterialDocumentHeader_2 — duplicate check
  ZAPI_MATERIAL_DOCUMENT_SRV             — post material document
"""

import os
import datetime
from typing import List, Dict

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel

import app.sap_client as sap

# ── App setup ─────────────────────────────────────────────────────────────────
application = FastAPI(
    title="Suprajit SAP Transaction Hub",
    description="SAP stock transfer via OData — FastAPI backend",
    version="2.0.0",
)

application.add_middleware(
    SessionMiddleware,
    secret_key=os.environ.get("SESSION_SECRET", "suprajit-sap-hub-secret-2026"),
    max_age=3600,          # 1 hour session
    https_only=False,      # Allow HTTP for internal SAP network
)

# ── Template & static paths ───────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
TMPL_DIR    = os.path.join(BASE_DIR, "templates")
STATIC_DIR  = os.path.join(BASE_DIR, "static")

templates = Jinja2Templates(directory=TMPL_DIR)
application.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# In-memory transaction history (per server restart)
transaction_history: List[Dict] = []


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_session_creds(request: Request):
    """Return (username, password, base_url, client) from session or raise 401."""
    session = request.session
    if "username" not in session:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return (
        session["username"],
        session["password"],
        session["base_url"],
        session["client"],
    )


# ── Request models ────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str
    base_url: str
    client: str

class PlantRequest(BaseModel):
    plant: str

class BatchDetailsRequest(BaseModel):
    batch_number: str
    plant: str
    from_storage: str

class AddBatchRequest(BaseModel):
    batch_number: str
    quantity: float
    remove_movement: bool = False
    plant: str
    from_storage: str

class UpdateQuantityRequest(BaseModel):
    batch_number: str
    quantity: float

class RemoveBatchRequest(BaseModel):
    batch_number: str

class PostTransactionRequest(BaseModel):
    from_storage: str
    to_storage: str
    movement_type: str = "311"
    header_text: str = ""


# ── Page routes ───────────────────────────────────────────────────────────────

@application.get("/", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@application.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    if "username" not in request.session:
        return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(
        "dashboard.html",
        {"request": request, "username": request.session["username"]},
    )


@application.get("/load_truck", response_class=HTMLResponse)
async def load_truck(request: Request):
    if "username" not in request.session:
        return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(
        "load_truck.html",
        {"request": request, "username": request.session["username"]},
    )


@application.get("/logout")
async def logout_get(request: Request):
    request.session.clear()
    return RedirectResponse(url="/", status_code=302)


# ── Auth API ──────────────────────────────────────────────────────────────────

@application.post("/login")
async def login(request: Request, body: LoginRequest):
    """
    Authenticate by connecting to SAP and fetching plants.
    Credentials are stored in the session — not in .env.
    """
    plants = sap.get_plants(
        body.username, body.password, body.base_url, body.client
    )

    if not plants:
        return JSONResponse(
            {"success": False, "message": "No plants found in SAP or connection failed."},
            status_code=401,
        )

    request.session["username"]  = body.username
    request.session["password"]  = body.password
    request.session["base_url"]  = body.base_url
    request.session["client"]    = body.client
    request.session["batch_items"] = []

    return {"success": True, "message": "Login successful", "plants": plants}


@application.post("/api/logout")
async def api_logout(request: Request):
    request.session.clear()
    return {"success": True}


# ── SAP API routes — match Flask app.py routes exactly ───────────────────────

@application.get("/api/health")
async def health():
    return {"status": "ok", "service": "Suprajit SAP Transaction Hub", "version": "2.0.0"}


@application.get("/api/get_plants")
async def api_get_plants(request: Request):
    """Fetch plants from SAP — ZUI_AT_TOOLS / ZI_BatchStocks."""
    username, password, base_url, client = get_session_creds(request)
    plants = sap.get_plants(username, password, base_url, client)
    return {"success": True, "plants": plants}


@application.post("/api/get_storage_locations")
async def api_get_storage_locations(request: Request, body: PlantRequest):
    """Fetch storage locations for a plant — ZUI_AT_TOOLS / ZI_BatchStocks."""
    username, password, base_url, client = get_session_creds(request)
    slocs = sap.get_storage_locations(username, password, base_url, client, body.plant)
    return {"success": True, "storage_locations": slocs}


@application.post("/api/get_batch_details")
async def api_get_batch_details(request: Request, body: BatchDetailsRequest):
    """Fetch batch details + stock — ZUI_AT_TOOLS / ZI_BatchStocks + I_Batch."""
    username, password, base_url, client = get_session_creds(request)

    details = sap.get_batch_details(
        username, password, base_url, client,
        body.batch_number, body.plant, body.from_storage,
    )

    if details.get("success"):
        stock = sap.check_batch_stock(
            username, password, base_url, client,
            details["material"], body.plant, body.from_storage, body.batch_number,
        )
        details["stock"] = stock

    return details


@application.post("/api/add_batch_item")
async def api_add_batch_item(request: Request, body: AddBatchRequest):
    """
    Validate batch against SAP then add to session batch list.
    Re-fetches batch details + stock on every add for freshness.
    """
    username, password, base_url, client = get_session_creds(request)

    # Fetch fresh batch details
    details = sap.get_batch_details(
        username, password, base_url, client,
        body.batch_number, body.plant, body.from_storage,
    )
    if not details.get("success"):
        return details

    # Check stock
    stock = sap.check_batch_stock(
        username, password, base_url, client,
        details["material"], body.plant, body.from_storage, body.batch_number,
    )

    if stock["unrestricted"] < body.quantity:
        return {
            "success": False,
            "message": (
                f"Insufficient stock. "
                f"Available: {stock['unrestricted']}, "
                f"Required: {body.quantity}"
            ),
        }

    batch_items = request.session.get("batch_items", [])

    # Duplicate check
    if any(item["batch"] == body.batch_number for item in batch_items):
        return {
            "success": False,
            "message": f"Batch {body.batch_number} already added",
            "batch_items": batch_items,
        }

    new_item = {
        "batch":           body.batch_number,
        "material":        details["material"],
        "material_name":   details.get("material_name", ""),
        "plant":           body.plant,
        "quantity":        body.quantity,
        "unit":            details.get("unit", "EA"),
        "remove_movement": body.remove_movement,
        "from_storage":    body.from_storage,
        "available_stock": stock["unrestricted"],
    }

    batch_items.append(new_item)
    request.session["batch_items"] = batch_items

    return {
        "success": True,
        "message": f"Batch {body.batch_number} added successfully",
        "batch_items": batch_items,
    }


@application.post("/api/update_quantity")
async def api_update_quantity(request: Request, body: UpdateQuantityRequest):
    """Update quantity for a batch item — re-validates stock against SAP."""
    username, password, base_url, client = get_session_creds(request)

    batch_items = request.session.get("batch_items", [])
    item = next((i for i in batch_items if i["batch"] == body.batch_number), None)

    if not item:
        return {
            "success": False,
            "message": f"Batch {body.batch_number} not found",
            "batch_items": batch_items,
        }

    stock = sap.check_batch_stock(
        username, password, base_url, client,
        item["material"], item["plant"], item["from_storage"], body.batch_number,
    )

    if stock["unrestricted"] < body.quantity:
        return {
            "success": False,
            "message": (
                f"Insufficient stock. "
                f"Available: {stock['unrestricted']}, "
                f"Required: {body.quantity}"
            ),
        }

    item["quantity"]        = body.quantity
    item["available_stock"] = stock["unrestricted"]
    request.session["batch_items"] = batch_items

    return {"success": True, "message": "Quantity updated", "batch_items": batch_items}


@application.post("/api/remove_batch_item")
async def api_remove_batch_item(request: Request, body: RemoveBatchRequest):
    """Remove one batch item from the session list."""
    batch_items = request.session.get("batch_items", [])
    batch_items = [i for i in batch_items if i["batch"] != body.batch_number]
    request.session["batch_items"] = batch_items
    return {
        "success": True,
        "message": f"Batch {body.batch_number} removed",
        "batch_items": batch_items,
    }


@application.post("/api/clear_all_items")
async def api_clear_all_items(request: Request):
    """Clear all batch items from the session list."""
    request.session["batch_items"] = []
    return {"success": True, "batch_items": []}


@application.post("/api/post_transaction")
async def api_post_transaction(request: Request, body: PostTransactionRequest):
    """
    Validate stock for all batch items then POST to ZAPI_MATERIAL_DOCUMENT_SRV.
    Clears session batch list on success.
    """
    username, password, base_url, client = get_session_creds(request)

    batch_items = request.session.get("batch_items", [])
    if not batch_items:
        return JSONResponse({"success": False, "error": "No batches to post"}, status_code=400)

    # Validate stock for all items before posting
    stock_errors = []
    for item in batch_items:
        stock = sap.check_batch_stock(
            username, password, base_url, client,
            item["material"], item["plant"], body.from_storage, item["batch"],
        )
        if stock["unrestricted"] < item["quantity"]:
            stock_errors.append({
                "batch":     item["batch"],
                "material":  item["material"],
                "available": stock["unrestricted"],
                "required":  item["quantity"],
            })

    if stock_errors:
        return {
            "success": False,
            "error": "Insufficient stock for some items",
            "stock_errors": stock_errors,
        }

    # Post to SAP via ZAPI_MATERIAL_DOCUMENT_SRV
    result = sap.post_material_document(
        username, password, base_url, client,
        batch_items,
        body.from_storage,
        body.to_storage,
        body.movement_type,
        body.header_text or f"Transfer {body.from_storage} to {body.to_storage}",
    )

    if result.get("success"):
        transaction_history.append({
            "timestamp":               result.get("timestamp", datetime.datetime.now().isoformat()),
            "material_document_number": result.get("material_document_number", ""),
            "from_storage":            body.from_storage,
            "to_storage":              body.to_storage,
            "batches":                 [i["batch"] for i in batch_items],
            "items_count":             len(batch_items),
        })
        request.session["batch_items"] = []

    return result


@application.get("/api/get_transaction_history")
async def api_get_transaction_history(request: Request):
    """Return in-memory transaction history for current server session."""
    get_session_creds(request)  # ensures authenticated
    return {"success": True, "transactions": transaction_history}


# ── App alias (uvicorn uses 'app') ────────────────────────────────────────────
app = application
