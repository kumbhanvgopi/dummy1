from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from sap_integration import (
    get_materials_by_batch,
    get_plants_from_sap,
    get_storage_locations_from_sap,
    get_batch_details_from_sap,
    get_material_description,
    check_batch_stock,
    add_batch_item,
    update_quantity,
    remove_batch_item,
    clear_all_items,
    post_transaction
)
import urllib3
import secrets
from functools import wraps

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Configuration - These will be set during login
BASE_URL = None
CLIENT = None

# Store transaction history in memory (in production, use database)
transaction_history = []

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return jsonify({'success': False, 'error': 'Not authenticated'}), 401
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username')
    password = request.json.get('password')
    base_url = request.json.get('base_url')
    client = request.json.get('client')
    
    # Store credentials and config in session
    session['username'] = username
    session['password'] = password
    session['base_url'] = base_url
    session['client'] = client
    
    # Test connection and fetch plants from SAP
    try:
        plants = get_plants_from_sap(username, password, base_url, client)
        
        if not plants:
            return jsonify({'success': False, 'message': 'No plants found in SAP or connection failed'}), 401
        
        return jsonify({'success': True, 'message': 'Login successful', 'plants': plants})
    except Exception as e:
        return jsonify({'success': False, 'message': f'SAP connection failed: {str(e)}'}), 401

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login_page'))
    return render_template('dashboard.html', username=session['username'])

@app.route('/load_truck')
def load_truck():
    """Load Truck interface"""
    if 'username' not in session:
        return redirect(url_for('login_page'))
    return render_template('load_truck.html', username=session['username'])

# API Routes for Load Truck functionality

@app.route('/api/get_plants', methods=['GET'])
@login_required
def api_get_plants():
    """Get list of plants directly from SAP"""
    plants = get_plants_from_sap(
        session['username'],
        session['password'],
        session['base_url'],
        session['client']
    )
    
    return jsonify({'success': True, 'plants': plants})

@app.route('/api/get_storage_locations', methods=['POST'])
@login_required
def api_get_storage_locations():
    """Get storage locations for a plant directly from SAP"""
    data = request.json
    plant = data.get('plant')
    
    storage_locations = get_storage_locations_from_sap(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        plant
    )
    
    return jsonify({
        'success': True,
        'storage_locations': storage_locations
    })

@app.route('/api/get_batch_details', methods=['POST'])
@login_required
def api_get_batch_details():
    """Get batch details directly from SAP"""
    data = request.json
    batch_number = data.get('batch_number')
    plant = data.get('plant')
    from_storage = data.get('from_storage')
    
    # First, get batch details
    batch_details = get_batch_details_from_sap(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        batch_number,
        plant,
        from_storage
    )
    
    if batch_details.get('success'):
        # Also check stock availability
        stock = check_batch_stock(
            session['username'],
            session['password'],
            session['base_url'],
            session['client'],
            batch_details.get('material'),
            plant,
            from_storage,
            batch_number
        )
        batch_details['stock'] = stock
    
    return jsonify(batch_details)

@app.route('/api/add_batch_item', methods=['POST'])
@login_required
def api_add_batch_item():
    """Add batch item to current transfer list"""
    data = request.json
    
    # Initialize batch items in session if not exists
    if 'batch_items' not in session:
        session['batch_items'] = []
    
    # Get fresh batch details from SAP
    batch_details = get_batch_details_from_sap(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        data.get('batch_number'),
        data.get('plant'),
        data.get('from_storage')
    )
    
    if not batch_details.get('success'):
        return jsonify(batch_details)
    
    # Check stock availability
    stock = check_batch_stock(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        batch_details.get('material'),
        data.get('plant'),
        data.get('from_storage'),
        data.get('batch_number')
    )
    
    if stock['unrestricted'] < data.get('quantity', 0):
        return jsonify({
            'success': False,
            'message': f'Insufficient stock. Available: {stock["unrestricted"]}, Required: {data.get("quantity")}'
        })
    
    # Create batch item with SAP data
    new_item = {
        'batch': data.get('batch_number'),
        'material': batch_details.get('material'),
        'material_name': batch_details.get('material_name'),
        'plant': data.get('plant'),
        'quantity': data.get('quantity'),
        'unit': batch_details.get('unit', 'PC'),
        'remove_movement': data.get('remove_movement', False),
        'from_storage': data.get('from_storage'),
        'available_stock': stock['unrestricted']
    }
    
    # Check if batch already exists
    existing = next((item for item in session['batch_items'] if item['batch'] == new_item['batch']), None)
    
    if existing:
        return jsonify({
            'success': False,
            'message': f'Batch {new_item["batch"]} already added',
            'batch_items': session['batch_items']
        })
    
    session['batch_items'].append(new_item)
    session.modified = True
    
    return jsonify({
        'success': True,
        'message': f'Batch {new_item["batch"]} added successfully',
        'batch_items': session['batch_items']
    })

@app.route('/api/update_quantity', methods=['POST'])
@login_required
def api_update_quantity():
    """Update quantity for a batch item"""
    data = request.json
    batch_number = data.get('batch_number')
    new_quantity = float(data.get('quantity'))
    
    # Find the batch item
    item = next((item for item in session.get('batch_items', []) if item['batch'] == batch_number), None)
    
    if not item:
        return jsonify({
            'success': False,
            'message': f'Batch {batch_number} not found',
            'batch_items': session.get('batch_items', [])
        })
    
    # Re-validate stock with SAP
    stock = check_batch_stock(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        item['material'],
        item['plant'],
        item['from_storage'],
        batch_number
    )
    
    if stock['unrestricted'] < new_quantity:
        return jsonify({
            'success': False,
            'message': f'Insufficient stock. Available: {stock["unrestricted"]}, Required: {new_quantity}'
        })
    
    item['quantity'] = new_quantity
    item['available_stock'] = stock['unrestricted']
    session.modified = True
    
    return jsonify({
        'success': True,
        'message': 'Quantity updated',
        'batch_items': session['batch_items']
    })

@app.route('/api/remove_batch_item', methods=['POST'])
@login_required
def api_remove_batch_item():
    """Remove batch item from list"""
    data = request.json
    batch_number = data.get('batch_number')
    
    session['batch_items'] = [item for item in session.get('batch_items', []) if item['batch'] != batch_number]
    session.modified = True
    
    return jsonify({
        'success': True,
        'message': f'Batch {batch_number} removed',
        'batch_items': session['batch_items']
    })

@app.route('/api/clear_all_items', methods=['POST'])
@login_required
def api_clear_all_items():
    """Clear all batch items"""
    session['batch_items'] = []
    session.modified = True
    
    return jsonify({'success': True, 'batch_items': []})

@app.route('/api/post_transaction', methods=['POST'])
@login_required
def api_post_transaction():
    """Post transaction to SAP and create material document"""
    data = request.json
    batch_items = session.get('batch_items', [])
    
    if not batch_items:
        return jsonify({'success': False, 'error': 'No batches to post'}), 400
    
    # Validate all items have sufficient stock
    stock_errors = []
    for item in batch_items:
        stock = check_batch_stock(
            session['username'],
            session['password'],
            session['base_url'],
            session['client'],
            item['material'],
            item['plant'],
            data.get('from_storage'),
            item['batch']
        )
        
        if stock['unrestricted'] < item['quantity']:
            stock_errors.append({
                'batch': item['batch'],
                'material': item['material'],
                'available': stock['unrestricted'],
                'required': item['quantity']
            })
    
    if stock_errors:
        return jsonify({
            'success': False,
            'error': 'Insufficient stock for some items',
            'stock_errors': stock_errors
        })
    
    # Post to SAP
    result = post_transaction(
        session['username'],
        session['password'],
        session['base_url'],
        session['client'],
        batch_items,
        data.get('from_storage'),
        data.get('to_storage'),
        data.get('movement_type', '311'),
        data.get('header_text', '')
    )
    
    if result.get('success'):
        # Add to transaction history
        transaction_history.append({
            'timestamp': result.get('timestamp'),
            'material_document_number': result.get('material_document_number'),
            'from_storage': data.get('from_storage'),
            'to_storage': data.get('to_storage'),
            'batches': [item['batch'] for item in batch_items],
            'items_count': len(batch_items)
        })
        
        # Clear session items after successful post
        session['batch_items'] = []
        session.modified = True
    
    return jsonify(result)

@app.route('/api/get_transaction_history', methods=['GET'])
@login_required
def api_get_transaction_history():
    """Get transaction history"""
    return jsonify({
        'success': True,
        'transactions': transaction_history
    })

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)