import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
import urllib3

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# SAP OData URL
url = (
    "https://10.1.2.57:44300/sap/opu/odata/sap/"
    "ZUI_AT_TOOLS/ZI_BatchStocks"
    "?sap-client=110"
    "&$select=Plant,StorageLocation,Batch"
    "&$format=json"
)

# SAP Credentials
username = "extsandeep"
password = "Welcome@123456789"

try:
    # API Call
    response = requests.get(
        url,
        auth=HTTPBasicAuth(username, password),
        verify=False
    )

    # Check response
    response.raise_for_status()

    # Convert response to JSON
    data = response.json()

    # Extract required fields
    records = []

    for item in data["d"]["results"]:
        records.append({
            "Plant": item.get("Plant", ""),
            "StorageLocation": item.get("StorageLocation", ""),
            "Batch": item.get("Batch", "")
        })

    # Create DataFrame
    df = pd.DataFrame(records)

    # Display all records
    print("\nBatch Stock Information:\n")
    print(df)

    # Optional: Save to Excel
    df.to_excel("BatchStocks.xlsx", index=False)

    print("\nData saved to BatchStocks.xlsx")

except requests.exceptions.RequestException as e:
    print(f"API Request Failed: {e}")

except Exception as e:
    print(f"Error: {e}")