document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      const baseUrl = document.getElementById('baseUrl').value;
      const client = document.getElementById('client').value;
      const errorDiv = document.getElementById('errorMessage');

      if (errorDiv) {
        errorDiv.style.display = 'none';
      }

      try {
        const response = await fetch('/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username,
            password,
            base_url: baseUrl,
            client
          })
        });

        const data = await response.json();

        if (data.success) {
          window.location.href = '/dashboard';
        } else {
          if (errorDiv) {
            errorDiv.textContent = data.message || 'Login failed';
            errorDiv.style.display = 'block';
          } else {
            alert(data.message || 'Login failed');
          }
        }
      } catch (error) {
        if (errorDiv) {
          errorDiv.textContent = 'Connection error. Please try again.';
          errorDiv.style.display = 'block';
        } else {
          alert('Connection error. Please try again.');
        }
      }
    });
  }
});
