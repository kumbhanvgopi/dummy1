import requests
import urllib3
import datetime
import random

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_materials_by_batch(username, password, base_url, client, batch_number):
    """Fetch materials by batch number - Direct SAP call"""
    
    entity = "I_Batch"
    url = (
        f"{base_url}/{entity}"
        f"?sap-client={client}"
        f"&$filter=Batch eq '{batch_number}'"
        f"&$select=Material,Plant,Batch,StorageLocation"
    )
    
    try:
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=30
        )
        
        if response.status_code != 200:
            print(f"Error fetching materials: {response.text}")
            return []
        
        data = response.json()
        materials = []
        
        for item in data.get("d", {}).get("results", []):
            materials.append({
                "Material": item.get("Material"),
                "Plant": item.get("Plant"),
                "Batch": item.get("Batch"),
                "StorageLocation": item.get("StorageLocation")
            })
        
        return materials
    except Exception as e:
        print(f"Error in get_materials_by_batch: {e}")
        return []

def get_plants_from_sap(username, password, base_url, client):
    """
    Fetch plants from SAP using batch stock view ZI_BatchStocks,
    similar to reference implementation.
    """
    url = f"{base_url}/ZI_BatchStocks?sap-client={client}&$top=1000"

    try:
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=30,
        )

        if response.status_code != 200:
            return []

        data = response.json()
        results = data.get("d", {}).get("results", [])

        if not results:
            return []

        plants_set = set()
        for item in results:
            plant = item.get("Plant") or item.get("Werks")
            if plant:
                plants_set.add(str(plant))

        if not plants_set:
            return []

        plants = [{"Plant": p, "PlantName": f"Plant {p}"} for p in sorted(plants_set)]
        return plants
    except Exception:
        return []

def get_storage_locations_from_sap(username, password, base_url, client, plant):
    """
    Fetch storage locations from ZI_BatchStocks for a plant,
    matching the reference implementation behaviour.
    """
    url = f"{base_url}/ZI_BatchStocks?sap-client={client}&$filter=Plant eq '{plant}'&$top=1000"

    try:
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=30,
        )

        if response.status_code != 200:
            return []

        data = response.json()
        results = data.get("d", {}).get("results", [])

        if not results:
            return []

        storage_set = set()
        for item in results:
            storage_loc = item.get("StorageLocation") or item.get("LGORT")
            if storage_loc:
                storage_set.add(str(storage_loc))

        if not storage_set:
            return []

        storage_locations = [
            {"StorageLocation": s, "StorageLocationName": f"Storage {s}"}
            for s in sorted(storage_set)
        ]
        return storage_locations
    except Exception:
        return []

def get_batch_details_from_sap(username, password, base_url, client, batch_number, plant, from_storage):
    """
    Get batch details using ZI_BatchStocks, following the reference code:
    - Filter by batch and plant (and storage location if provided)
    - Return material, description, quantity, unit, storage location, etc.
    """
    filter_parts = [f"Batch eq '{batch_number}'", f"Plant eq '{plant}'"]
    if from_storage:
        filter_parts.append(f"StorageLocation eq '{from_storage}'")

    filter_str = " and ".join(filter_parts)
    url = f"{base_url}/ZI_BatchStocks?sap-client={client}&$filter={filter_str}"

    try:
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=30,
        )

        if response.status_code != 200:
            return {
                "success": False,
                "message": f"HTTP {response.status_code}: {response.text[:200]}",
            }

        data = response.json()
        results = data.get("d", {}).get("results", [])

        if not results:
            return {
                "success": False,
                "message": f"Batch {batch_number} not found in plant {plant}",
            }

        item = results[0]
        batch_details = {
            "Material": item.get("Material") or item.get("Matnr"),
            "Plant": item.get("Plant") or item.get("Werks") or plant,
            "Batch": item.get("Batch") or item.get("CHARG") or batch_number,
            "MaterialName": item.get("MaterialName") or item.get("MAKTX") or "",
            "Quantity": item.get("Quantity") or item.get("LABST") or 0,
            "Unit": item.get("Unit") or item.get("MEINS") or "EA",
            "StorageLocation": item.get("StorageLocation") or item.get("LGORT") or from_storage,
        }

        if not batch_details["Material"]:
            return {
                "success": False,
                "message": f"Material not found for batch {batch_number}",
            }

        return {
            "success": True,
            "batch": batch_details["Batch"],
            "material": batch_details["Material"],
            "material_name": batch_details["MaterialName"],
            "plant": batch_details["Plant"],
            "unit": batch_details["Unit"],
            "quantity": float(batch_details["Quantity"] or 0),
            "storage_location": batch_details["StorageLocation"],
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Error fetching batch details: {str(e)}",
        }

def check_batch_stock(username, password, base_url, client, material, plant, storage_location, batch):
    """Check unrestricted stock for a batch directly from SAP"""
    
    # Try standard stock entity
    stock_entities = ["I_Stock", "I_MaterialStock", "StockOverviewSet"]
    
    for entity in stock_entities:
        try:
            url = (
                f"{base_url}/{entity}"
                f"?sap-client={client}"
                f"&$filter=Material eq '{material}' and Plant eq '{plant}' "
                f"and StorageLocation eq '{storage_location}' and Batch eq '{batch}'"
                f"&$select=Material,Plant,StorageLocation,Batch,UnrestrictedStock,QualityStock,BlockedStock"
            )
            
            response = requests.get(
                url,
                auth=(username, password),
                headers={"Accept": "application/json"},
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                results = data.get("d", {}).get("results", [])
                if results:
                    return {
                        'unrestricted': float(results[0].get("UnrestrictedStock", 0)),
                        'quality': float(results[0].get("QualityStock", 0)),
                        'blocked': float(results[0].get("BlockedStock", 0))
                    }
        except:
            continue
    
    return {'unrestricted': 0, 'quality': 0, 'blocked': 0}

def create_material_document_in_sap(username, password, base_url, client, batch_items, from_storage, to_storage, movement_type, header_text):
    """Create material document in SAP using BAPI/RFC"""
    
    # In production, you would call SAP RFC/BAPI here
    # For now, simulate with a note that actual SAP call needed
    
    timestamp = datetime.datetime.now()
    
    # This is where you would implement actual SAP RFC call
    # Example using pyrfc or SAP NetWeaver RFC SDK:
    """
    from pyrfc import Connection
    
    conn = Connection(ashost='sapserver', sysnr='00', client='110', user=username, passwd=password)
    
    goods_mvt_items = []
    for item in batch_items:
        goods_mvt_items.append({
            'MATERIAL': item['material'],
            'PLANT': item['plant'],
            'STGE_LOC': from_storage,
            'BATCH': item['batch'],
            'ENTRY_QNT': item['quantity'],
            'MOVE_TYPE': movement_type,
            'MOVE_STLOC': to_storage
        })
    
    result = conn.call('BAPI_GOODSMVT_CREATE', 
                       GOODSMVT_HEADER={'PSTNG_DATE': datetime.date.today()},
                       GOODSMVT_ITEM=goods_mvt_items)
    
    if result['RETURN'][0]['TYPE'] == 'S':
        conn.call('BAPI_TRANSACTION_COMMIT')
        document_number = result['MATERIALDOCUMENT']
    """
    
    # For now, return simulated document number
    # Replace with actual SAP BAPI call
    doc_number = f"5{timestamp.strftime('%Y%m%d%H%M%S')}{random.randint(10,99)}"
    
    return {
        'success': True,
        'material_document_number': doc_number,
        'timestamp': timestamp.isoformat()
    }

def add_batch_item(batch_items, batch_number, quantity, remove_movement, plant, from_storage):
    """Add batch item to the list (validates with SAP)"""
    
    # Check if batch already exists
    existing = next((item for item in batch_items if item['batch'] == batch_number), None)
    
    if existing:
        return {
            'success': False,
            'message': f'Batch {batch_number} already added',
            'batch_items': batch_items
        }
    
    return {
        'success': True,
        'message': f'Batch {batch_number} added successfully',
        'batch_items': batch_items
    }

def update_quantity(batch_items, batch_number, new_quantity):
    """Update quantity for a batch item"""
    
    item = next((item for item in batch_items if item['batch'] == batch_number), None)
    
    if not item:
        return {
            'success': False,
            'message': f'Batch {batch_number} not found',
            'batch_items': batch_items
        }
    
    item['quantity'] = float(new_quantity)
    
    return {
        'success': True,
        'message': 'Quantity updated',
        'batch_items': batch_items
    }

def remove_batch_item(batch_items, batch_number):
    """Remove batch item from list"""
    
    updated_items = [item for item in batch_items if item['batch'] != batch_number]
    
    return {
        'success': True,
        'message': f'Batch {batch_number} removed',
        'batch_items': updated_items
    }

def clear_all_items(batch_items):
    """Clear all batch items"""
    
    return {
        'success': True,
        'message': 'All items cleared',
        'batch_items': []
    }

def post_transaction(username, password, base_url, client, batch_items, from_storage, to_storage, movement_type, header_text):
    """Post transaction to SAP and create material document"""
    
    if not batch_items:
        return {
            'success': False,
            'message': 'No batches to post'
        }
    
    # Validate stock for each batch item
    stock_errors = []
    validated_items = []
    
    for item in batch_items:
        # Check stock in SAP
        stock = check_batch_stock(
            username, password, base_url, client,
            item['material'], item['plant'], from_storage, item['batch']
        )
        
        if stock['unrestricted'] < item['quantity']:
            stock_errors.append({
                'batch': item['batch'],
                'material': item['material'],
                'available': stock['unrestricted'],
                'required': item['quantity']
            })
        else:
            validated_items.append(item)
    
    if stock_errors:
        error_msg = "Insufficient stock for:\n"
        for err in stock_errors:
            error_msg += f"Batch {err['batch']}: Available {err['available']}, Required {err['required']}\n"
        return {
            'success': False,
            'message': error_msg,
            'stock_errors': stock_errors
        }
    
    # Create material document in SAP
    result = create_material_document_in_sap(
        username, password, base_url, client,
        validated_items, from_storage, to_storage, movement_type, header_text
    )
    
    return result

def get_material_description(username, password, base_url, client, material):
    """Get material description from SAP"""
    
    try:
        url = f"{base_url}/I_Material?sap-client={client}&$filter=Material eq '{material}'&$select=Material,MaterialName"
        
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            verify=False,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            results = data.get("d", {}).get("results", [])
            if results:
                return results[0].get("MaterialName") or material
        
        return material
    except:
        return material
